﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RoadReady.Exceptions;
using RoadReady.Interface;
using RoadReady.Models;
using RoadReady.Services;

namespace RoadReady.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("ReactPolicy")]
    public class RentalStoreController : ControllerBase
    {
        private readonly IRentalStoreAdminService _rentalStoreAdminService;
        private readonly IRentalStoreUserService _rentalStoreUserService;

        public RentalStoreController(IRentalStoreAdminService rentalStoreAdminService, IRentalStoreUserService rentalStoreUserService)
        {
            _rentalStoreAdminService = rentalStoreAdminService;
            _rentalStoreUserService = rentalStoreUserService;
        }

        //Admin Actions
        [Authorize(Roles = "admin,user")]
        [HttpGet("admin/user/Getall")]
        public async Task<ActionResult<List<RentalStore>>> GetAllRentalStores()
        {
            try
            {
                var rentalStores = await _rentalStoreAdminService.GetAllRentalStores();
                if (rentalStores == null || rentalStores.Count == 0)
                {
                    return NotFound("No rental stores found.");
                }
                return Ok(rentalStores);
            }
            catch (RentalStoreListEmptyException)
            {
                return NotFound("Rental store list is empty.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while getting all rental stores: {ex.Message}");
            }
        }

        [Authorize(Roles = "admin,user")]
        [HttpGet("admin/user/cars/{storeId}")]
        public async Task<ActionResult<List<CarStore>>> GetCarsInStore(int storeId)
        {
            try
            {
                var carStores = await _rentalStoreAdminService.GetCarsInStore(storeId);
                if (carStores == null || carStores.Count == 0)
                {
                    return NotFound($"No cars found in rental store with ID {storeId}.");
                }
                return Ok(carStores);
            }
            catch (NoSuchCarException)
            {
                return NotFound($"No cars found in rental store with ID {storeId}.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while getting cars in the rental store: {ex.Message}");
            }
        }

        //User Action
        [Authorize(Roles = "user")]
        [HttpPost("user/addRental")]
        public async Task<ActionResult<RentalStore>> AddRentalStore(RentalStore rentalStore)
        {
            try
            {
                var addedRentalStore = await _rentalStoreUserService.AddRentalStore(rentalStore);
                return Ok(addedRentalStore);
            }
            catch (RentalStoreAlreadyExistsException ex)
            {
                return Conflict($"Rental store with ID {rentalStore.StoreId} already exists.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while adding the rental store: {ex.Message}");
            }
        }

        [Authorize(Roles = "user")]
        [HttpPut("user/update")]
        public async Task<ActionResult<RentalStore>> UpdateRentalStoreDetails(RentalStore rentalStore)
        {
            try
            {
                var updatedRentalStore = await _rentalStoreUserService.UpdateRentalStoreDetails(rentalStore.StoreId, rentalStore.PickUpStoreLocation, rentalStore.DropOffStoreLocation);
                if (updatedRentalStore == null)
                {
                    return NotFound($"Rental store with ID {rentalStore.StoreId} not found.");
                }
                return Ok(updatedRentalStore);
            }
            catch (NoSuchRentalStoreException ex)
            {
                return NotFound($"Rental store with ID {rentalStore.StoreId} not found.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while updating the rental store details: {ex.Message}");
            }
        }

        [Authorize(Roles = "user")]
        [HttpDelete("user/{id}")]
        public async Task<ActionResult<RentalStore>> RemoveRentalStore(int id)
        {
            try
            {
                var removedRentalStore = await _rentalStoreUserService.RemoveRentalStore(id);
                if (removedRentalStore == null)
                {
                    return NotFound($"Rental store with ID {id} not found.");
                }
                return Ok("Deleted SuccessFully");
            }
            catch (NoSuchRentalStoreException ex)
            {
                return NotFound($"Rental store with ID {id} not found.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while deleting the rental store: {ex.Message}");
            }
        }

        [Authorize(Roles = "user")]
        [HttpGet("user/{storeId}")]
        public async Task<ActionResult<RentalStore>> GetRentalStoreById(int storeId)
        {
            try
            {
                var rentalStore = await _rentalStoreUserService.GetRentalStoreById(storeId);
                if (rentalStore == null)
                {
                    return NotFound($"Rental store with ID {storeId} not found.");
                }
                return Ok(rentalStore);
            }
            catch (NoSuchRentalStoreException ex)
            {
                return NotFound($"No rental store found with ID {storeId}: {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while getting rental store by ID: {ex.Message}");
            }
        }


    }
}
