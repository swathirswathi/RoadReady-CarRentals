﻿namespace RoadReady.Models.DTO
{
    public class AdminEmailDto
    {
        public int AdminId { get; set; }
        public string Email { get; set; }
    }
}
