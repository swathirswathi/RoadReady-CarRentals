﻿namespace RoadReady.Models.DTO
{
    public class ReservationPriceDto
    {
        public int ReservationId { get; set; }
        public double TotalPrice { get; set; }
    }
}
