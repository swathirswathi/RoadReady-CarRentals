﻿namespace RoadReady.Models.DTO
{
    public class CarSpecificationDto
    {
        public int CarId { get; set; }
        public string Specification { get; set; }
    }
}
