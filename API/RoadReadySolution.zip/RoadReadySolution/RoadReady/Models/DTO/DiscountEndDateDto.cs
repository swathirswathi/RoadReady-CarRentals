﻿namespace RoadReady.Models.DTO
{
    public class DiscountEndDateDto
    {
        public int DiscountId { get; set; }
        public DateTime EndDateOfDiscount { get; set; }
    }
}
