﻿namespace RoadReady.Models.DTO
{
    public class AdminPhoneNumberDto
    {
        public int AdminId { get; set; }
        public string PhoneNumber { get; set; }
    }
}
