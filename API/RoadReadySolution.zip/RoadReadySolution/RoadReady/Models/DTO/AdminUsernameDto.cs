﻿namespace RoadReady.Models.DTO
{
    public class AdminUsernameDto
    {
        public int AdminId { get; set; }
        public string Username { get; set; }
    }
}
