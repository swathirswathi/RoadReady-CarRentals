﻿namespace RoadReady.Models.DTO
{
    public class UserPasswordDto
    {
        public int UserId { get; set; }
        public byte[] Password { get; set; }
    }
}
