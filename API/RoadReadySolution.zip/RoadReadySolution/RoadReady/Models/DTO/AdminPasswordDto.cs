﻿namespace RoadReady.Models.DTO
{
    public class AdminPasswordDto
    {
        public int AdminId { get; set; }
        public byte[] Password { get; set; }
    }
}
