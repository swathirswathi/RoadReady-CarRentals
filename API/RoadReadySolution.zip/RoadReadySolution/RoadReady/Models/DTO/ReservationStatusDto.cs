﻿namespace RoadReady.Models.DTO
{
    public class ReservationStatusDto
    {
        public int ReservationId { get; set; }
        public string Status { get; set; }
    }
}
