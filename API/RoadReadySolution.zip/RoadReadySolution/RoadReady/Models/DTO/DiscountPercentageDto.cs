﻿namespace RoadReady.Models.DTO
{
    public class DiscountPercentageDto
    {
        public int DiscountId { get; set; }
        public double DiscountPercentage { get; set; }
    }
}
