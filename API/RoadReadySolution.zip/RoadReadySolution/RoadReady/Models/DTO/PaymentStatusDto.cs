﻿namespace RoadReady.Models.DTO
{
    public class PaymentStatusDto
    {
        public int PaymentId { get; set; }
        public string PaymentStatus { get; set; }
    }
}
