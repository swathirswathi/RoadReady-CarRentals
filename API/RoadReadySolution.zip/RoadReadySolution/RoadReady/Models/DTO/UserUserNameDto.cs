﻿namespace RoadReady.Models.DTO
{
    public class UserUserNameDto
    {
        public int UserId { get; set; }
        public string Username { get; set; }
    }
}
