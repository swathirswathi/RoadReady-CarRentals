﻿namespace RoadReady.Models.DTO
{
    public class CarAvailibilityDto
    {
        public int CarId { get; set; }
        public bool Availability { get; set; } = true;
    }
}
