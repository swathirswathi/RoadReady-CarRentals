﻿namespace RoadReady.Models.DTO
{
    public class CarDailyRateDto
    {
        public int CarId { get; set; }
        public double DailyRate { get; set; }
    }
}
