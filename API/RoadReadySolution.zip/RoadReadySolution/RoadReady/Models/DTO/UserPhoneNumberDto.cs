﻿namespace RoadReady.Models.DTO
{
    public class UserPhoneNumberDto
    {
        public int UserId { get; set; }
        public string PhoneNumber { get; set; }
    }
}
