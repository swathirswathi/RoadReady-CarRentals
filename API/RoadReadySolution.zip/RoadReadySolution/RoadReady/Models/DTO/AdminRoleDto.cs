﻿namespace RoadReady.Models.DTO
{
    public class AdminRoleDto
    {
        public int AdminId { get; set; }
        public string Role { get; set; }
    }
}
