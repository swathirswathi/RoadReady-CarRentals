﻿namespace RoadReady.Models.DTO
{
    public class UserEmailDto
    {
        public int UserId { get; set; }
        public string Email { get; set; }
    }
}
